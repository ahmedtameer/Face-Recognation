import cv2
import numpy as np
import face_recognition

imgTam = face_recognition.load_image_file('4.PNG')
imgTam = cv2.cvtColor(imgTam,cv2.COLOR_BGR2RGB)

faceLoc = face_recognition.face_locations(imgTam)[0]
encodeTam = face_recognition.face_encodings(imgTam)[0]
cv2.rectangle(imgTam,(faceLoc[3],faceLoc[0]),(faceLoc[1],faceLoc[2]),(255,0,255),2)

cv2.imshow('Ahmed Tamer',imgTam)
cv2.waitKey(0)